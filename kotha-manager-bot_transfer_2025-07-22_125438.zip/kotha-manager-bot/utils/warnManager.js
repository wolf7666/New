const warns = {};
module.exports = {
    warnUser: (userId, reason) => {
        if (!warns[userId]) warns[userId] = [];
        warns[userId].push({ reason, date: new Date() });
        console.log(`Warned ${userId}: ${reason}`);
    }
};