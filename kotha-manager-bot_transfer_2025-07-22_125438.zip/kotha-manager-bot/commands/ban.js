module.exports = {
    name: 'ban',
    execute(message) {
        if (!message.member.permissions.has('BAN_MEMBERS')) return;
        const user = message.mentions.members.first();
        if (user) user.ban();
    }
}