module.exports = {
    name: 'purge',
    execute(message, args) {
        if (!message.member.permissions.has('MANAGE_MESSAGES')) return;
        const amount = parseInt(args[0]);
        if (!isNaN(amount)) message.channel.bulkDelete(amount);
    }
}