module.exports = {
    name: 'mute',
    execute(message) {
        const user = message.mentions.members.first();
        const role = message.guild.roles.cache.find(r => r.name === "Muted");
        if (user && role) user.roles.add(role);
    }
}