module.exports = {
    name: 'kick',
    execute(message) {
        if (!message.member.permissions.has('KICK_MEMBERS')) return;
        const user = message.mentions.members.first();
        if (user) user.kick();
    }
}