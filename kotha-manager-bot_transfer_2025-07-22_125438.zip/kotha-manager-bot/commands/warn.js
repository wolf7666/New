const warnManager = require('../utils/warnManager');
module.exports = {
    name: 'warn',
    execute(message, args) {
        const user = message.mentions.users.first();
        const reason = args.slice(1).join(' ') || 'No reason';
        if (user) warnManager.warnUser(user.id, reason);
    }
}