module.exports = (client) => {
    client.on('guildBanAdd', ban => {
        console.log(`Ban detected: ${ban.user.tag}`);
        // Logic to alert or auto-restrict dangerous moderators can go here.
    });
}