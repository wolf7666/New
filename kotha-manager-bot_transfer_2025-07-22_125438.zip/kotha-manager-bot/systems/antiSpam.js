const userMessages = {};
module.exports = (client) => {
    client.on('messageCreate', message => {
        if (message.author.bot) return;
        const key = `${message.guild.id}-${message.author.id}`;
        if (!userMessages[key]) userMessages[key] = [];
        userMessages[key].push({ content: message.content, timestamp: Date.now() });
        userMessages[key] = userMessages[key].filter(m => Date.now() - m.timestamp < 60000);
        const repeated = userMessages[key].filter(m => m.content === message.content);
        if (repeated.length >= 5) {
            const role = message.guild.roles.cache.find(r => r.name === "Muted");
            if (role) message.member.roles.add(role).catch(console.error);
        }
    });
}